# Log-Analysis-Using-Regular-Expressions
Using Regular expression to pull the required data from the log file.
**Insight : **
 (1) Use regex to parse a log file
 (2) Append and modify values in a dictionary
 (3) Write to a file in CSV format
